/* ============================================================
   Bulldog CBO — Shell + UI atoms
   ============================================================ */

/* ---------- Buttons ---------- */
function Button({ variant = 'primary', size = 'md', icon, iconRight, full, children, className = '', ...rest }) {
  const cls = `btn btn--${variant} btn--${size}${full ? ' btn--full' : ''} ${className}`;
  return (
    <button className={cls} {...rest}>
      {icon && <Icon name={icon} size={size === 'sm' ? 16 : 18} />}
      {children && <span>{children}</span>}
      {iconRight && <Icon name={iconRight} size={size === 'sm' ? 16 : 18} />}
    </button>
  );
}

/* ---------- Badge ---------- */
function Badge({ tone = 'neutral', icon, children, className = '' }) {
  return (
    <span className={`badge badge--${tone} ${className}`}>
      {icon && <Icon name={icon} size={12} stroke={2.4} />}
      {children}
    </span>
  );
}

/* ---------- Tab pill ---------- */
function Pill({ active, icon, children, onClick }) {
  return (
    <button className={`pill${active ? ' pill--on' : ''}`} onClick={onClick}>
      {icon && <Icon name={icon} size={15} />}
      {children}
    </button>
  );
}

/* ---------- Card ---------- */
function Card({ className = '', children, ...rest }) {
  return <div className={`card ${className}`} {...rest}>{children}</div>;
}

/* ---------- Logo tile ---------- */
function LogoTile({ size = 40, radius = 11 }) {
  return (
    <span className="logo-tile" style={{ width: size, height: size, borderRadius: radius }}>
      <img src="assets/bulldog-logo.png" alt="Bulldog Hotdog" />
    </span>
  );
}

/* ---------- Sidebar ---------- */
function Sidebar({ current, onNavigate }) {
  return (
    <aside className="sidebar">
      <div className="sidebar__brand">
        <LogoTile size={42} />
        <div className="brand-text">
          <span className="brand-name">Bulldog</span>
          <span className="brand-sub">CBO · Punto de venta</span>
        </div>
      </div>

      <nav className="sidebar__nav">
        {NAV.map(n => (
          <button
            key={n.id}
            className={`navitem${current === n.id ? ' navitem--on' : ''}`}
            onClick={() => onNavigate(n.id)}
          >
            <span className="navitem__icon"><Icon name={n.icon} size={20} /></span>
            <span className="navitem__label">{n.label}</span>
            {current === n.id && <span className="navitem__dot" />}
          </button>
        ))}
      </nav>

      <div className="sidebar__foot">
        <div className="shift-chip">
          <span className="dot-live" />
          <span>{`Turno #${SHIFT.num} activo`}</span>
        </div>
        <div className="user-row">
          <span className="avatar">DB</span>
          <div className="user-meta">
            <span className="user-name">Dueño Bulldog</span>
            <span className="user-role">Administrador</span>
          </div>
          <Badge tone="mustard" icon="crown">Dueño</Badge>
        </div>
      </div>
    </aside>
  );
}

/* ---------- Topbar ---------- */
function Topbar({ title, subtitle, right, onMenu }) {
  return (
    <header className="topbar">
      <div className="topbar__left">
        <button className="topbar__menu" onClick={onMenu}><Icon name="more" size={22} /></button>
        <div>
          <h1 className="topbar__title">{title}</h1>
          {subtitle && <p className="topbar__sub">{subtitle}</p>}
        </div>
      </div>
      <div className="topbar__right">
        {right}
        <div className="rate-chip" title="Tasa de cambio">
          <Icon name="swap" size={15} />
          <span>Bs <b>{RATE.toFixed(2)}</b></span>
        </div>
        <Badge tone="green" icon="clock">{`Turno #${SHIFT.num}`}</Badge>
      </div>
    </header>
  );
}

/* ---------- Mobile bottom nav ---------- */
function MobileNav({ current, onNavigate }) {
  const items = MOBILE_NAV.map(id => NAV.find(n => n.id === id));
  return (
    <nav className="mobilenav">
      {items.map(n => (
        <button
          key={n.id}
          className={`mnav${current === n.id ? ' mnav--on' : ''}`}
          onClick={() => onNavigate(n.id)}
        >
          <Icon name={n.icon} size={22} />
          <span>{n.label}</span>
        </button>
      ))}
      <button className="mnav" onClick={() => onNavigate('sistema')}>
        <Icon name="more" size={22} />
        <span>Más</span>
      </button>
    </nav>
  );
}

Object.assign(window, { Button, Badge, Pill, Card, LogoTile, Sidebar, Topbar, MobileNav });
