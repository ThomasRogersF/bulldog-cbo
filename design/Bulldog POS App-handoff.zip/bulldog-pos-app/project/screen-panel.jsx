/* ============================================================
   Bulldog CBO — Panel (dashboard)
   ============================================================ */

function KpiCard({ k }) {
  const val = k.kind === 'usd' ? usd(k.value) : k.value.toLocaleString('es-VE');
  const subs = {
    ventas: bs(k.value),
    pedidos: '≈ 15 pedidos / hora',
    ticket: bs(k.value),
    clients: '0,9 tickets por cliente',
  };
  const deltaTxt = k.kind === 'usd' ? `+${k.delta}%` : `+${k.delta}`;
  return (
    <Card className="kpi">
      <div className="kpi__top">
        <span className="kpi__icon"><Icon name={k.icon} size={19} /></span>
        <span className="kpi__delta"><Icon name="arrowUp" size={12} stroke={2.6} />{deltaTxt}</span>
      </div>
      <div className="kpi__label">{k.label}</div>
      <div className="kpi__value">{val}</div>
      <div className="kpi__sub">{subs[k.id]}</div>
    </Card>
  );
}

function HourChart() {
  const max = Math.max(...HOURLY.map(d => d.v));
  const peak = HOURLY.findIndex(d => d.v === max);
  const total = HOURLY.reduce((a, d) => a + d.v, 0);
  return (
    <Card className="chart">
      <div className="card__head">
        <div>
          <h3 className="card__title">Ventas por hora</h3>
          <p className="card__sub">Servicio de hoy · 08:00 – 15:00</p>
        </div>
        <div className="chart__total">
          <span className="chart__total-num">{usd(total)}</span>
          <span className="chart__total-bs">{bs(total)}</span>
        </div>
      </div>
      <div className="chart__plot">
        <div className="chart__ylabels">
          {[1, 0.75, 0.5, 0.25, 0].map((g, i) => (
            <span key={i}>{usd(max * g).replace('.00', '')}</span>
          ))}
        </div>
        <div className="chart__lines" />
        <div className="chart__bars">
          {HOURLY.map((d, i) => (
            <div className="barcol" key={d.h}>
              <div className="barslot">
                <span className="barval" style={{ opacity: i === peak ? 1 : 0.5 }}>{d.v}</span>
                <div className={`bar${i === peak ? ' bar--peak' : ''}`} style={{ height: `${(d.v / max) * 90}%` }} />
              </div>
              <span className="barlbl">{d.h}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

function TopProducts() {
  const max = Math.max(...TOP.map(t => t.units));
  return (
    <Card className="topcard">
      <div className="card__head">
        <h3 className="card__title">Top 5 productos</h3>
        <Badge tone="outline" icon="crown">Más vendidos</Badge>
      </div>
      <div className="toplist">
        {TOP.map((t, i) => (
          <div className="toprow" key={t.name}>
            <span className={`rank${i === 0 ? ' rank--gold' : ''}`}>{i + 1}</span>
            <div className="toprow__main">
              <div className="toprow__head">
                <span className="toprow__name">{t.name}</span>
                <span className="toprow__units">{t.units} <i>uds</i></span>
              </div>
              <div className="track"><div className="track__fill" style={{ width: `${(t.units / max) * 100}%` }} /></div>
            </div>
            <span className="toprow__rev">{usd(t.revenue)}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

function ShiftCard({ onClose }) {
  return (
    <Card className="shiftcard">
      <div className="shiftcard__main">
        <div className="shiftcard__title">
          <span className="dot-live" />
          <h3>Turno activo</h3>
          <Badge tone="mustard">{`#${SHIFT.num}`}</Badge>
        </div>
        <div className="shiftcard__stats">
          <div className="sstat"><span className="sstat__l">Abierto por</span><span className="sstat__v">{SHIFT.openedBy}</span></div>
          <div className="sstat"><span className="sstat__l">Apertura</span><span className="sstat__v">{SHIFT.opened}</span></div>
          <div className="sstat"><span className="sstat__l">Duración</span><span className="sstat__v">{SHIFT.duration}</span></div>
          <div className="sstat"><span className="sstat__l">Pedidos</span><span className="sstat__v">{SHIFT.orders}</span></div>
          <div className="sstat"><span className="sstat__l">Ventas del turno</span><span className="sstat__v sstat__v--hi">{usd(SHIFT.sales)}</span></div>
        </div>
      </div>
      <Button variant="danger" icon="x" onClick={onClose}>Cerrar turno</Button>
    </Card>
  );
}

function LowStock({ onGo }) {
  const lvlLabel = { low: 'Crítico', mid: 'Bajo' };
  return (
    <Card className="lowstock">
      <div className="card__head">
        <div className="lowstock__title">
          <h3 className="card__title">Stock bajo</h3>
          <Badge tone="red">{LOW_STOCK.length}</Badge>
        </div>
        <button className="linkbtn" onClick={onGo}>Ver inventario <Icon name="arrowRight" size={15} /></button>
      </div>
      <div className="lowgrid">
        {LOW_STOCK.map(it => {
          const pct = Math.round(it.pct * 100);
          return (
            <div className={`lowitem lowitem--${it.level}`} key={it.name}>
              <div className="lowitem__top">
                <span className="lowitem__name">{it.name}</span>
                <Badge tone={it.level === 'low' ? 'red' : 'amber'}>{lvlLabel[it.level]}</Badge>
              </div>
              <div className="lowitem__qty">{it.qty} <span>{it.unit}</span> <i>de {it.par} {it.unit}</i></div>
              <div className="track track--sm"><div className={`track__fill track__fill--${it.level}`} style={{ width: `${Math.max(pct, 6)}%` }} /></div>
              <Button variant="secondary" size="sm" icon="refill" full onClick={onGo}>Reponer</Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function PanelScreen({ onNavigate }) {
  return (
    <div className="screen panel">
      <div className="kpi-row">
        {KPIS.map(k => <KpiCard key={k.id} k={k} />)}
      </div>
      <div className="panel-mid">
        <HourChart />
        <TopProducts />
      </div>
      <ShiftCard onClose={() => {}} />
      <LowStock onGo={() => onNavigate('ingredientes')} />
    </div>
  );
}

Object.assign(window, { PanelScreen });
