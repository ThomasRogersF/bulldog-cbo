/* ============================================================
   Bulldog CBO — App root + routing
   ============================================================ */

const META = {
  panel:        { title: 'Panel',          sub: 'Resumen del turno de hoy' },
  pos:          { title: 'Punto de venta', sub: 'Arma el pedido y cobra' },
  ingredientes: { title: 'Ingredientes',   sub: 'Inventario y reposición' },
  sistema:      { title: 'Sistema',        sub: 'Lenguaje visual de Bulldog CBO' },
};

function Placeholder({ id }) {
  const n = NAV.find(x => x.id === id) || { label: id, icon: 'grid' };
  return (
    <div className="screen placeholder">
      <div className="placeholder__box">
        <span className="placeholder__ic"><Icon name={n.icon} size={30} /></span>
        <h3>{n.label}</h3>
        <p>Esta sección comparte el mismo sistema visual. Aún no forma parte de este rediseño — dime si quieres que la construyamos.</p>
        <Badge tone="outline">Próximamente</Badge>
      </div>
    </div>
  );
}

function App() {
  const [screen, setScreen] = React.useState(() => {
    try { return localStorage.getItem('bulldog.screen') || 'panel'; } catch (e) { return 'panel'; }
  });
  const go = (id) => {
    setScreen(id);
    try { localStorage.setItem('bulldog.screen', id); } catch (e) {}
  };

  const meta = META[screen] || { title: (NAV.find(n => n.id === screen) || {}).label || '', sub: '' };

  let body;
  if (screen === 'panel') body = <PanelScreen onNavigate={go} />;
  else if (screen === 'pos') body = <PosScreen />;
  else if (screen === 'ingredientes') body = <IngredientesScreen />;
  else if (screen === 'sistema') body = <SistemaScreen />;
  else body = <Placeholder id={screen} />;

  return (
    <div className="app">
      <Sidebar current={screen} onNavigate={go} />
      <div className="main">
        <Topbar title={meta.title} subtitle={meta.sub} />
        <div className="content">{body}</div>
      </div>
      <MobileNav current={screen} onNavigate={go} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
