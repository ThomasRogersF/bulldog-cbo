/* ============================================================
   Bulldog CBO — App data (realistic demo data, es-VE)
   ============================================================ */

const RATE = 40; // Tasa: 1 USD = 40 Bs (matches existing system)

function usd(n) {
  return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function bs(n) {
  return (Number(n) * RATE).toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Bs';
}

/* ---------- Navigation ---------- */
const NAV = [
  { id: 'panel',        label: 'Panel',          icon: 'home' },
  { id: 'pos',          label: 'Punto de venta', icon: 'register' },
  { id: 'pedidos',      label: 'Pedidos',        icon: 'receipt' },
  { id: 'ingredientes', label: 'Ingredientes',   icon: 'box' },
  { id: 'menu',         label: 'Menú',           icon: 'utensils' },
  { id: 'clientes',     label: 'Clientes',       icon: 'users' },
  { id: 'turnos',       label: 'Turnos',         icon: 'clock' },
  { id: 'sistema',      label: 'Sistema',        icon: 'grid' },
  { id: 'config',       label: 'Configuración',  icon: 'gear' },
];
// Bottom mobile nav (primary actions)
const MOBILE_NAV = ['panel', 'pos', 'pedidos', 'ingredientes'];

/* ---------- Dashboard KPIs ---------- */
const KPIS = [
  { id: 'ventas',  label: 'Ventas hoy',       icon: 'cash',    value: 578.00, kind: 'usd', delta: +12.4 },
  { id: 'pedidos', label: 'Pedidos hoy',      icon: 'bag',     value: 63,     kind: 'int', delta: +8 },
  { id: 'ticket',  label: 'Ticket promedio',  icon: 'tag',     value: 9.18,   kind: 'usd', delta: +3.1 },
  { id: 'clients', label: 'Clientes atendidos',icon: 'users',  value: 58,     kind: 'int', delta: +6 },
];

/* ---------- Sales by hour ---------- */
const HOURLY = [
  { h: '08', v: 12 }, { h: '09', v: 25 }, { h: '10', v: 41 }, { h: '11', v: 68 },
  { h: '12', v: 124 }, { h: '13', v: 156 }, { h: '14', v: 98 }, { h: '15', v: 54 },
];

/* ---------- Top products ---------- */
const TOP = [
  { name: 'Perro Clásico',       cat: 'perros',       units: 38, revenue: 114.00 },
  { name: 'Hamburguesa Clásica', cat: 'hamburguesas', units: 31, revenue: 155.00 },
  { name: 'Papas Fritas',        cat: 'acompanantes', units: 27, revenue: 67.50 },
  { name: 'Refresco',            cat: 'bebidas',      units: 24, revenue: 36.00 },
  { name: 'Perro Especial',      cat: 'perros',       units: 19, revenue: 85.50 },
];

/* ---------- Active shift ---------- */
const SHIFT = {
  num: 3, openedBy: 'Dueño Bulldog', duration: '4h 18m', orders: 63, sales: 578.00, opened: '10:42 a.m.',
};

/* ---------- Menu ---------- */
const CATEGORIES = [
  { id: 'todo',         label: 'Todo' },
  { id: 'perros',       label: 'Perros' },
  { id: 'hamburguesas', label: 'Hamburguesas' },
  { id: 'bebidas',      label: 'Bebidas' },
  { id: 'acompanantes', label: 'Acompañantes' },
  { id: 'extras',       label: 'Extras' },
];

const MENU = [
  { id: 'p1', name: 'Perro Clásico',       price: 3.00, cat: 'perros',       glyph: 'hotdog',  desc: 'Salchicha, papitas y salsas', popular: true },
  { id: 'p2', name: 'Perro Especial',      price: 4.50, cat: 'perros',       glyph: 'hotdog',  desc: 'Doble salchicha, tocineta, queso', popular: true },
  { id: 'p3', name: 'Perro Mixto',         price: 5.00, cat: 'perros',       glyph: 'hotdog',  desc: 'Salchicha + carne mechada' },
  { id: 'h1', name: 'Hamburguesa Clásica', price: 5.00, cat: 'hamburguesas', glyph: 'burger',  desc: 'Carne, queso, vegetales', popular: true },
  { id: 'h2', name: 'Hamburguesa Doble',   price: 7.00, cat: 'hamburguesas', glyph: 'burger',  desc: 'Doble carne y queso' },
  { id: 'h3', name: 'Hamburguesa BBQ',     price: 7.50, cat: 'hamburguesas', glyph: 'burger',  desc: 'Salsa BBQ, cebolla crujiente' },
  { id: 'b1', name: 'Refresco',            price: 1.50, cat: 'bebidas',      glyph: 'soda',    desc: 'Lata 355 ml', popular: true },
  { id: 'b2', name: 'Agua Mineral',        price: 1.00, cat: 'bebidas',      glyph: 'water',   desc: 'Botella 600 ml' },
  { id: 'b3', name: 'Malta',               price: 1.50, cat: 'bebidas',      glyph: 'soda',    desc: 'Lata 355 ml' },
  { id: 'a1', name: 'Papas Fritas',        price: 2.50, cat: 'acompanantes', glyph: 'fries',   desc: 'Porción regular', popular: true },
  { id: 'a2', name: 'Papas con Queso',     price: 3.50, cat: 'acompanantes', glyph: 'fries',   desc: 'Con queso cheddar fundido' },
  { id: 'a3', name: 'Tequeños (5u)',       price: 4.00, cat: 'acompanantes', glyph: 'stick',   desc: '5 unidades crujientes' },
  { id: 'e1', name: 'Salsa extra',         price: 0.50, cat: 'extras',       glyph: 'sauce',   desc: 'Mayo, mostaza o ketchup' },
  { id: 'e2', name: 'Queso extra',         price: 1.00, cat: 'extras',       glyph: 'sauce',   desc: 'Cheddar fundido' },
  { id: 'e3', name: 'Tocineta extra',      price: 1.50, cat: 'extras',       glyph: 'sauce',   desc: 'Porción de tocineta' },
];

/* ---------- Payment methods ---------- */
const PAYMENTS = [
  { id: 'efectivo_usd', label: 'Efectivo USD', icon: 'cash' },
  { id: 'efectivo_bs',  label: 'Efectivo Bs',  icon: 'cash' },
  { id: 'tarjeta',      label: 'Tarjeta',      icon: 'card' },
  { id: 'pago_movil',   label: 'Pago móvil',   icon: 'phone' },
  { id: 'transferencia',label: 'Transferencia',icon: 'bank' },
  { id: 'zinli',        label: 'Zinli',        icon: 'wallet' },
  { id: 'binance',      label: 'Binance',      icon: 'coin' },
  { id: 'paypal',       label: 'PayPal',       icon: 'globe' },
  { id: 'credito',      label: 'Crédito',      icon: 'creditclock' },
];

/* ---------- Ingredients ---------- */
const ING_CATS = [
  { id: 'todos',     label: 'Todos' },
  { id: 'carnes',    label: 'Carnes' },
  { id: 'panes',     label: 'Panes' },
  { id: 'salsas',    label: 'Salsas' },
  { id: 'bebidas',   label: 'Bebidas' },
  { id: 'vegetales', label: 'Vegetales' },
  { id: 'otros',     label: 'Otros' },
];

const INGREDIENTS = [
  { name: 'Carne de hamburguesa', qty: 57,   par: 80,   unit: 'u',  cat: 'carnes' },
  { name: 'Salchicha',            qty: 64,   par: 90,   unit: 'u',  cat: 'carnes' },
  { name: 'Carne mechada',        qty: 1.2,  par: 4,    unit: 'kg', cat: 'carnes' },
  { name: 'Pan de hamburguesa',   qty: 58,   par: 80,   unit: 'u',  cat: 'panes' },
  { name: 'Pan de perro',         qty: 12,   par: 80,   unit: 'u',  cat: 'panes' },
  { name: 'Mayonesa',             qty: 3910, par: 5000, unit: 'ml', cat: 'salsas' },
  { name: 'Mostaza',              qty: 480,  par: 2000, unit: 'ml', cat: 'salsas' },
  { name: 'Ketchup',              qty: 2400, par: 4000, unit: 'ml', cat: 'salsas' },
  { name: 'Salsa de ajo',         qty: 320,  par: 1500, unit: 'ml', cat: 'salsas' },
  { name: 'Refresco lata',        qty: 71,   par: 96,   unit: 'u',  cat: 'bebidas' },
  { name: 'Agua mineral',         qty: 40,   par: 72,   unit: 'u',  cat: 'bebidas' },
  { name: 'Malta',                qty: 18,   par: 48,   unit: 'u',  cat: 'bebidas' },
  { name: 'Tomate',               qty: 3.1,  par: 6,    unit: 'kg', cat: 'vegetales' },
  { name: 'Cebolla',              qty: 4.0,  par: 6,    unit: 'kg', cat: 'vegetales' },
  { name: 'Repollo',              qty: 2.4,  par: 5,    unit: 'kg', cat: 'vegetales' },
  { name: 'Queso',                qty: 320,  par: 3000, unit: 'g',  cat: 'otros' },
  { name: 'Papas',                qty: 20,   par: 30,   unit: 'kg', cat: 'otros' },
  { name: 'Servilletas',          qty: 220,  par: 500,  unit: 'u',  cat: 'otros' },
];

function stockLevel(it) {
  const pct = it.qty / it.par;
  if (pct < 0.2) return 'low';
  if (pct < 0.5) return 'mid';
  return 'ok';
}

// Low-stock alerts for the dashboard
const LOW_STOCK = INGREDIENTS
  .map(it => ({ ...it, pct: it.qty / it.par, level: stockLevel(it) }))
  .filter(it => it.level !== 'ok')
  .sort((a, b) => a.pct - b.pct)
  .slice(0, 4);

Object.assign(window, {
  RATE, usd, bs, NAV, MOBILE_NAV, KPIS, HOURLY, TOP, SHIFT,
  CATEGORIES, MENU, PAYMENTS, ING_CATS, INGREDIENTS, stockLevel, LOW_STOCK,
});
