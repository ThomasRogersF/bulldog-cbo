/* ============================================================
   Bulldog CBO — POS (Punto de venta)
   ============================================================ */

function ProductTile({ item, qtyInCart, onAdd }) {
  const catLabel = (CATEGORIES.find(c => c.id === item.cat) || {}).label || '';
  return (
    <button className={`tile${qtyInCart ? ' tile--active' : ''}`} onClick={() => onAdd(item)}>
      <div className="tile__img">
        <FoodGlyph name={item.glyph} size={34} />
        {item.popular && <span className="tile__star"><Icon name="flame" size={13} stroke={2} /></span>}
        <span className="tile__cat">{catLabel}</span>
        {qtyInCart > 0 && <span className="tile__count">{qtyInCart}</span>}
      </div>
      <div className="tile__body">
        <span className="tile__name">{item.name}</span>
        <span className="tile__desc">{item.desc}</span>
        <div className="tile__price">
          <span className="tile__usd">{usd(item.price)}</span>
          <span className="tile__bs">{bs(item.price)}</span>
        </div>
      </div>
      <span className="tile__add"><Icon name="plus" size={18} stroke={2.6} /></span>
    </button>
  );
}

function CartLine({ line, onInc, onDec, onRemove }) {
  return (
    <div className="cartline">
      <div className="cartline__info">
        <span className="cartline__name">{line.name}</span>
        <span className="cartline__unit">{usd(line.price)} c/u</span>
      </div>
      <div className="stepper">
        <button onClick={() => onDec(line.id)} aria-label="menos"><Icon name="minus" size={15} stroke={2.6} /></button>
        <span className="stepper__n">{line.qty}</span>
        <button onClick={() => onInc(line.id)} aria-label="más"><Icon name="plus" size={15} stroke={2.6} /></button>
      </div>
      <div className="cartline__right">
        <span className="cartline__total">{usd(line.price * line.qty)}</span>
        <button className="cartline__del" onClick={() => onRemove(line.id)} aria-label="quitar"><Icon name="trash" size={16} /></button>
      </div>
    </div>
  );
}

function PosScreen() {
  const [cat, setCat] = React.useState('todo');
  const [cart, setCart] = React.useState([
    { id: 'h1', name: 'Hamburguesa Clásica', price: 5.00, qty: 1 },
    { id: 'a1', name: 'Papas Fritas', price: 2.50, qty: 1 },
    { id: 'p1', name: 'Perro Clásico', price: 3.00, qty: 2 },
  ]);
  const [orderType, setOrderType] = React.useState('aqui');
  const [payment, setPayment] = React.useState('efectivo_usd');
  const [discount, setDiscount] = React.useState(0);
  const [client, setClient] = React.useState(null);
  const [done, setDone] = React.useState(false);

  const items = cat === 'todo' ? MENU : MENU.filter(m => m.cat === cat);
  const qtyOf = id => (cart.find(l => l.id === id) || {}).qty || 0;

  const add = (m) => setCart(c => {
    const ex = c.find(l => l.id === m.id);
    if (ex) return c.map(l => l.id === m.id ? { ...l, qty: l.qty + 1 } : l);
    return [...c, { id: m.id, name: m.name, price: m.price, qty: 1 }];
  });
  const inc = id => setCart(c => c.map(l => l.id === id ? { ...l, qty: l.qty + 1 } : l));
  const dec = id => setCart(c => c.flatMap(l => l.id === id ? (l.qty > 1 ? [{ ...l, qty: l.qty - 1 }] : []) : [l]));
  const remove = id => setCart(c => c.filter(l => l.id !== id));

  const subtotal = cart.reduce((a, l) => a + l.price * l.qty, 0);
  const total = Math.max(0, subtotal - Number(discount || 0));
  const count = cart.reduce((a, l) => a + l.qty, 0);
  const empty = cart.length === 0;

  const confirm = () => {
    setDone(true);
    setTimeout(() => { setDone(false); setCart([]); setDiscount(0); setClient(null); }, 1600);
  };

  return (
    <div className="screen pos">
      {/* LEFT: catalog */}
      <div className="pos__catalog">
        <div className="pos__cat-head">
          <div className="searchbox">
            <Icon name="search" size={17} />
            <input placeholder="Buscar producto…" />
          </div>
          <span className="pos__count">{items.length} de {MENU.length} productos</span>
        </div>

        <div className="tabs">
          {CATEGORIES.map(c => (
            <Pill key={c.id} active={cat === c.id} onClick={() => setCat(c.id)}>{c.label}</Pill>
          ))}
        </div>

        <div className="grid">
          {items.map(m => (
            <ProductTile key={m.id} item={m} qtyInCart={qtyOf(m.id)} onAdd={add} />
          ))}
        </div>
      </div>

      {/* RIGHT: cart */}
      <div className="pos__cart">
        <div className="ordertype">
          <button className={`ot${orderType === 'aqui' ? ' ot--on' : ''}`} onClick={() => setOrderType('aqui')}>
            <Icon name="utensils" size={18} /> Para aquí
          </button>
          <button className={`ot${orderType === 'llevar' ? ' ot--on' : ''}`} onClick={() => setOrderType('llevar')}>
            <Icon name="bag" size={18} /> Para llevar
          </button>
        </div>

        <button className="clientrow" onClick={() => setClient(client ? null : { name: 'María González' })}>
          <span className="clientrow__l"><Icon name="users" size={16} /> Cliente</span>
          <span className="clientrow__v">{client ? client.name : 'Sin cliente'}</span>
          <Icon name={client ? 'x' : 'plus'} size={16} />
        </button>

        {empty ? (
          <div className="cart-empty">
            <div className="cart-empty__ic"><Icon name="cart" size={34} /></div>
            <h4>Agrega ítems al pedido</h4>
            <p>Toca un producto del menú para empezar a armar la orden.</p>
          </div>
        ) : (
          <div className="cart-lines">
            {cart.map(l => <CartLine key={l.id} line={l} onInc={inc} onDec={dec} onRemove={remove} />)}
          </div>
        )}

        {!empty && (
          <div className="cart-foot">
            <div className="discount">
              <span className="discount__l"><Icon name="percent" size={15} /> Descuento</span>
              <div className="discount__in">
                <span>$</span>
                <input type="number" min="0" value={discount} onChange={e => setDiscount(e.target.value)} placeholder="0.00" />
              </div>
            </div>

            <div className="totals">
              <div className="totals__row"><span>Subtotal</span><span>{usd(subtotal)}</span></div>
              {Number(discount) > 0 && <div className="totals__row totals__row--disc"><span>Descuento</span><span>– {usd(Number(discount))}</span></div>}
              <div className="totals__row totals__row--grand">
                <span>Total</span>
                <div className="totals__amt"><span className="totals__usd">{usd(total)}</span><span className="totals__bs">{bs(total)}</span></div>
              </div>
            </div>

            <div className="paysec">
              <span className="paysec__l">Método de pago</span>
              <div className="paygrid">
                {PAYMENTS.map(p => (
                  <button key={p.id} className={`pay${payment === p.id ? ' pay--on' : ''}`} onClick={() => setPayment(p.id)}>
                    <Icon name={p.icon} size={18} />
                    <span>{p.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="cart-actions">
          <Button variant="primary" size="lg" full icon="check" disabled={empty} onClick={confirm}>
            {empty ? 'Sin productos' : `Confirmar pedido · ${usd(total)}`}
          </Button>
          <div className="cart-actions__row">
            <Button variant="secondary" size="sm" icon="pin" disabled={empty}>Aparcar</Button>
            <Button variant="ghost" size="sm" icon="receipt" disabled={empty}>Orden existente</Button>
          </div>
        </div>
      </div>

      {done && (
        <div className="toast-ok">
          <span className="toast-ok__ic"><Icon name="check" size={20} stroke={3} /></span>
          Pedido confirmado · {count} ítems
        </div>
      )}
    </div>
  );
}

Object.assign(window, { PosScreen });
