/* ============================================================
   Bulldog CBO — Ingredientes (inventory)
   ============================================================ */

const MOVES = [
  { t: '14:38', name: 'Pan de perro', delta: -6, unit: 'u', who: 'POS · Turno #3', kind: 'out' },
  { t: '14:05', name: 'Queso', delta: -180, unit: 'g', who: 'POS · Turno #3', kind: 'out' },
  { t: '13:20', name: 'Mayonesa', delta: +1000, unit: 'ml', who: 'Reposición · Dueño', kind: 'in' },
  { t: '12:47', name: 'Salchicha', delta: -14, unit: 'u', who: 'POS · Turno #3', kind: 'out' },
  { t: '11:10', name: 'Carne de hamburguesa', delta: +40, unit: 'u', who: 'Reposición · Dueño', kind: 'in' },
  { t: '10:42', name: 'Mostaza', delta: -120, unit: 'ml', who: 'Ajuste · merma', kind: 'out' },
];

function IngredientCard({ it }) {
  const level = stockLevel(it);
  const pct = Math.round((it.qty / it.par) * 100);
  const labels = { ok: 'En nivel', mid: 'Stock bajo', low: 'Crítico' };
  const tones = { ok: 'green', mid: 'amber', low: 'red' };
  const catLabel = (ING_CATS.find(c => c.id === it.cat) || {}).label || '';
  return (
    <Card className={`ing ing--${level}`}>
      <div className="ing__head">
        <div className="ing__id">
          <h4 className="ing__name">{it.name}</h4>
          <div className="ing__tags">
            <span className="chip">{catLabel}</span>
            <span className="chip chip--unit">{it.unit}</span>
          </div>
        </div>
        <div className="ing__qty">
          {it.qty}<span>{it.unit}</span>
        </div>
      </div>

      <div className="ing__barwrap">
        <div className="track track--lg">
          <div className={`track__fill track__fill--${level}`} style={{ width: `${Math.max(pct, 4)}%` }} />
        </div>
        <div className="ing__meta">
          <span className="ing__pct"><b>{pct}%</b> de {it.par} {it.unit}</span>
          <Badge tone={tones[level]} icon={level === 'low' ? 'alert' : level === 'mid' ? 'bell' : 'check'}>{labels[level]}</Badge>
        </div>
      </div>

      <div className="ing__btns">
        <Button variant="primary" size="sm" icon="refill" full>Reponer</Button>
        <Button variant="secondary" size="sm" icon="edit" full>Ajustar</Button>
      </div>
    </Card>
  );
}

function MovesView() {
  return (
    <Card className="moves">
      <div className="card__head">
        <h3 className="card__title">Movimientos recientes</h3>
        <Badge tone="outline">Hoy</Badge>
      </div>
      <div className="moves__list">
        {MOVES.map((m, i) => (
          <div className="move" key={i}>
            <span className="move__t">{m.t}</span>
            <span className={`move__ic move__ic--${m.kind}`}>
              <Icon name={m.kind === 'in' ? 'arrowDown' : 'arrowUp'} size={15} stroke={2.6} />
            </span>
            <div className="move__info">
              <span className="move__name">{m.name}</span>
              <span className="move__who">{m.who}</span>
            </div>
            <span className={`move__delta move__delta--${m.kind}`}>{m.delta > 0 ? '+' : ''}{m.delta} {m.unit}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

function IngredientesScreen() {
  const [tab, setTab] = React.useState('stock');
  const [cat, setCat] = React.useState('todos');
  const list = cat === 'todos' ? INGREDIENTS : INGREDIENTS.filter(i => i.cat === cat);
  const lows = INGREDIENTS.filter(i => stockLevel(i) === 'low').length;

  return (
    <div className="screen ingredientes">
      <div className="ing-top">
        <div className="segmented">
          <button className={`seg${tab === 'stock' ? ' seg--on' : ''}`} onClick={() => setTab('stock')}>
            <Icon name="box" size={17} /> Stock
          </button>
          <button className={`seg${tab === 'moves' ? ' seg--on' : ''}`} onClick={() => setTab('moves')}>
            <Icon name="swap" size={17} /> Movimientos
          </button>
        </div>
        {lows > 0 && (
          <div className="ing-alert">
            <Icon name="alert" size={16} />
            <b>{lows}</b> ingredientes en nivel crítico
          </div>
        )}
      </div>

      {tab === 'stock' ? (
        <>
          <div className="tabs">
            {ING_CATS.map(c => (
              <Pill key={c.id} active={cat === c.id} onClick={() => setCat(c.id)}>{c.label}</Pill>
            ))}
          </div>
          <div className="inggrid">
            {list.map(it => <IngredientCard key={it.name} it={it} />)}
          </div>
        </>
      ) : <MovesView />}
    </div>
  );
}

Object.assign(window, { IngredientesScreen });
