/* ============================================================
   Bulldog CBO — Sistema (design system reference)
   ============================================================ */

function Swatch({ name, hex, val, dark, ring }) {
  return (
    <div className="swatch">
      <span className="swatch__chip" style={{ background: hex, color: dark ? '#000' : '#fff', boxShadow: ring ? 'inset 0 0 0 1px rgba(255,255,255,.14)' : 'none' }} />
      <span className="swatch__name">{name}</span>
      <span className="swatch__hex">{hex}</span>
      {val && <span className="swatch__val">{val}</span>}
    </div>
  );
}

function DSGroup({ title, kicker, children }) {
  return (
    <Card className="dsgroup">
      <div className="dsgroup__head">
        <span className="dsgroup__kicker">{kicker}</span>
        <h3>{title}</h3>
      </div>
      {children}
    </Card>
  );
}

function SistemaScreen() {
  return (
    <div className="screen sistema">
      <Card className="ds-hero">
        <img className="ds-hero__logo" src="assets/bulldog-badge.png" alt="Bulldog Hotdog" />
        <div className="ds-hero__txt">
          <span className="ds-hero__kicker">Sistema de diseño</span>
          <h2>Bulldog CBO</h2>
          <p>Negro como lienzo, mostaza como héroe. Tipografía robusta, superficies tranquilas y una sola voz visual en todo el punto de venta — la energía de la calle, con la precisión de una herramienta de trabajo.</p>
          <div className="ds-hero__tags">
            <Badge tone="mustard">#FDCD01</Badge>
            <Badge tone="outline">Negro · Blanco</Badge>
            <Badge tone="outline">es-VE · USD + Bs</Badge>
            <Badge tone="outline">Touch 48px+</Badge>
          </div>
        </div>
      </Card>

      <div className="ds-grid">
        <DSGroup kicker="01" title="Paleta">
          <div className="swatches">
            <Swatch name="Mostaza" hex="#FDCD01" dark />
            <Swatch name="Mostaza prof." hex="#E0B400" dark />
            <Swatch name="Lienzo" hex="#100F0D" ring />
            <Swatch name="Superficie" hex="#1A1916" ring />
            <Swatch name="Superficie 2" hex="#242220" ring />
            <Swatch name="Texto" hex="#F4F1E9" dark />
            <Swatch name="Éxito" hex="#3DD68C" dark />
            <Swatch name="Alerta" hex="#FFB020" dark />
            <Swatch name="Peligro" hex="#FF5247" />
          </div>
        </DSGroup>

        <DSGroup kicker="02" title="Tipografía">
          <div className="typescale">
            <div className="tr"><span className="tr__n" style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-.02em' }}>Display 800</span><span className="tr__m">Archivo · 38 / -2%</span></div>
            <div className="tr"><span className="tr__n" style={{ fontSize: 26, fontWeight: 800 }}>Título 800</span><span className="tr__m">Archivo · 26</span></div>
            <div className="tr"><span className="tr__n" style={{ fontSize: 18, fontWeight: 700 }}>Subtítulo 700</span><span className="tr__m">Archivo · 18</span></div>
            <div className="tr"><span className="tr__n" style={{ fontSize: 15, fontWeight: 500 }}>Cuerpo 500</span><span className="tr__m">Archivo · 15</span></div>
            <div className="tr"><span className="tr__n" style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>Etiqueta 700</span><span className="tr__m">Archivo · 11 · +12%</span></div>
            <div className="tr"><span className="tr__n" style={{ fontSize: 24, fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>$578.00 · 23.120,00 Bs</span><span className="tr__m">Cifras tabulares</span></div>
          </div>
        </DSGroup>

        <DSGroup kicker="03" title="Botones">
          <div className="ds-row">
            <Button variant="primary" icon="check">Confirmar</Button>
            <Button variant="secondary" icon="refill">Reponer</Button>
            <Button variant="ghost" icon="receipt">Orden</Button>
            <Button variant="danger" icon="x">Cerrar turno</Button>
          </div>
          <div className="ds-row">
            <Button variant="primary" size="sm" icon="plus">Pequeño</Button>
            <Button variant="secondary" size="sm" icon="edit">Ajustar</Button>
            <Button variant="primary" disabled>Deshabilitado</Button>
          </div>
        </DSGroup>

        <DSGroup kicker="04" title="Insignias">
          <div className="ds-row">
            <Badge tone="mustard" icon="crown">Dueño</Badge>
            <Badge tone="green" icon="clock">Turno #3</Badge>
            <Badge tone="red" icon="alert">Crítico</Badge>
            <Badge tone="amber" icon="bell">Bajo</Badge>
            <Badge tone="outline">Etiqueta</Badge>
            <Badge tone="neutral">Neutral</Badge>
          </div>
          <div className="ds-row">
            <Pill active>Activa</Pill>
            <Pill>Inactiva</Pill>
            <span className="stepper ds-stepper">
              <button><Icon name="minus" size={15} stroke={2.6} /></button>
              <span className="stepper__n">2</span>
              <button><Icon name="plus" size={15} stroke={2.6} /></button>
            </span>
          </div>
        </DSGroup>

        <DSGroup kicker="05" title="Barras de stock">
          <div className="ds-bars">
            {[['En nivel', 'ok', 78], ['Stock bajo', 'mid', 32], ['Crítico', 'low', 12]].map(([l, lv, p]) => (
              <div className="ds-barrow" key={lv}>
                <span className="ds-barrow__l">{l}</span>
                <div className="track track--lg"><div className={`track__fill track__fill--${lv}`} style={{ width: p + '%' }} /></div>
                <span className="ds-barrow__p">{p}%</span>
              </div>
            ))}
          </div>
        </DSGroup>

        <DSGroup kicker="06" title="KPI · superficie">
          <div className="kpi ds-kpi">
            <div className="kpi__top">
              <span className="kpi__icon"><Icon name="cash" size={19} /></span>
              <span className="kpi__delta"><Icon name="arrowUp" size={12} stroke={2.6} />+12.4%</span>
            </div>
            <div className="kpi__label">Ventas hoy</div>
            <div className="kpi__value">$578.00</div>
            <div className="kpi__sub">23.120,00 Bs</div>
          </div>
        </DSGroup>
      </div>
    </div>
  );
}

Object.assign(window, { SistemaScreen });
